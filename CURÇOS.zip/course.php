<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

include('conexao.php');
$course_id = $_GET['course_id'];
$sql = "SELECT * FROM lessons WHERE course_id='$course_id'";
$lessons = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Curso</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>Curso</h1>
    <ul>
        <?php while($lesson = $lessons->fetch_assoc()) { ?>
            <li><a href="lesson.php?lesson_id=<?= $lesson['id'] ?>"><?= $lesson['title'] ?></a></li>
        <?php } ?>
    </ul>
</body>
</html>
