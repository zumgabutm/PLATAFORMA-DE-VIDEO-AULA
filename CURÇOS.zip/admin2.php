<?php
session_start();
include('conexao.php');

// Processar remoção de vídeo
if (isset($_GET['delete'])) {
    $video_id = intval($_GET['delete']);
    $sql = "DELETE FROM videos WHERE id = $video_id";
    if ($conn->query($sql) === TRUE) {
        echo "<p>Vídeo removido com sucesso.</p>";
    } else {
        echo "<p>Erro ao remover o vídeo: " . $conn->error . "</p>";
    }
}

// Processar upload ou URL de vídeo
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $category = $_POST['category'];
    $file_path = $_POST['file_path'];

    if (isset($_FILES['video_file']) && $_FILES['video_file']['error'] === UPLOAD_ERR_OK) {
        // Processar upload de arquivo de vídeo
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["video_file"]["name"]);
        $uploadOk = 1;
        $videoFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Verificar se o arquivo é um vídeo com base na extensão
        $allowed_types = ['mp4', 'avi', 'mov', 'wmv'];
        if (in_array($videoFileType, $allowed_types)) {
            $uploadOk = 1;
        } else {
            echo "Desculpe, somente arquivos MP4, AVI, MOV & WMV são permitidos.";
            $uploadOk = 0;
        }

        // Verificar o tamanho do arquivo
        if ($_FILES["video_file"]["size"] > 50000000) { // Limite de 50MB
            echo "Desculpe, o arquivo é muito grande.";
            $uploadOk = 0;
        }

        // Verificar se $uploadOk é 0 devido a um erro
        if ($uploadOk == 0) {
            echo "Desculpe, seu arquivo não foi enviado.";
        } else {
            if (move_uploaded_file($_FILES["video_file"]["tmp_name"], $target_file)) {
                $file_path = $target_file; // Atualizar o caminho do arquivo para o caminho de upload
            } else {
                echo "Desculpe, houve um erro ao carregar seu arquivo.";
            }
        }
    } elseif (!empty($file_path)) {
        // Processar URL de vídeo
        $file_path = filter_var($file_path, FILTER_SANITIZE_URL);
    } else {
        echo "Por favor, forneça um arquivo de vídeo ou um URL.";
        $file_path = ''; // Garantir que file_path esteja vazio para evitar inserção inválida
    }

    if (!empty($file_path)) {
        $sql = "INSERT INTO videos (title, description, category, file_path) VALUES ('$title', '$description', '$category', '$file_path')";
        if ($conn->query($sql) === TRUE) {
            echo "O vídeo foi carregado e adicionado com sucesso.";
        } else {
            echo "Erro ao adicionar o vídeo: " . $conn->error;
        }
    }
}

// Consultar vídeos existentes
$sql = "SELECT * FROM videos ORDER BY id DESC";
$videos_result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Gerenciar Vídeos</title>
    <link rel="stylesheet" type="text/css" href="home.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        h1 {
            color: #333;
        }
        .form-container {
            margin-bottom: 20px;
        }
        .video-grid {
            display: flex;
            flex-wrap: wrap;
        }
        .video-item {
            width: 30%;
            margin: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 10px;
            border-radius: 5px;
            background: #fff;
        }
        .video-item h2 {
            font-size: 18px;
            margin: 0;
        }
        .video-item p {
            font-size: 14px;
            color: #555;
        }
        .video-item video, .video-item iframe {
            width: 100%;
            border-radius: 5px;
        }
        .button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 5px;
        }
        .button-danger {
            background-color: #dc3545;
        }
    </style>
</head>
<body>
    <h1>Gerenciar Vídeos</h1>

    <!-- Formulário de Adição de Vídeo -->
    <div class="form-container">
        <h2>Adicionar Vídeo</h2>
        <form method="post" enctype="multipart/form-data" action="admin2.php">
            <label for="title">Título:</label>
            <input type="text" id="title" name="title" required>
            <br>
            <label for="description">Descrição:</label>
            <textarea id="description" name="description" required></textarea>
            <br>
            <label for="category">Categoria:</label>
            <select id="category" name="category" required>
                <option value="ANDROID">ANDROID</option>
                <option value="WIFI">WIFI</option>
                <option value="PEN_TEST">PEN_TEST</option>
                <option value="INFORMATICA">INFORMATICA</option>
                <option value="MODIFICACOES">MODIFICAÇÕES</option>
                <option value="METODOS">MÉTODOS</option>
            </select>
            <br>
            <label for="file_path">URL do Vídeo (para YouTube):</label>
            <input type="text" id="file_path" name="file_path">
            <br>
            <label for="video_file">Arquivo de Vídeo (para upload):</label>
            <input type="file" id="video_file" name="video_file">
            <br>
            <input type="submit" value="Adicionar Vídeo">
        </form>
    </div>

    <!-- Listar Vídeos -->
    <div class="form-container">
        <h2>Vídeos Cadastrados</h2>
        <?php if ($videos_result->num_rows > 0): ?>
            <div class="video-grid">
                <?php while ($row = $videos_result->fetch_assoc()): ?>
                    <div class="video-item">
                        <h2><?php echo htmlspecialchars($row['title']); ?></h2>
                        <p><?php echo htmlspecialchars($row['description']); ?></p>
                        <?php
                        $url = htmlspecialchars($row['file_path']);
                        if (strpos($url, 'youtube.com') !== false || strpos($url, 'youtu.be') !== false):
                            // Extrair o ID do vídeo do YouTube
                            preg_match('/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:v\/|embed\/|watch\?v=)|youtu\.be\/)([^\s"&?\/]{11})/', $url, $matches);
                            $video_id = $matches[1] ?? null;

                            if ($video_id):
                        ?>
                            <iframe src="https://www.youtube.com/embed/<?php echo $video_id; ?>" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        <?php else: ?>
                            <p>URL do vídeo inválida.</p>
                        <?php endif; ?>
                        <?php elseif (filter_var($url, FILTER_VALIDATE_URL)): ?>
                            <!-- Vídeo a partir de um link -->
                            <video controls>
                                <source src="<?php echo $url; ?>" type="video/mp4">
                                Seu navegador não suporta o elemento de vídeo.
                            </video>
                        <?php else: ?>
                            <!-- Vídeo carregado por upload -->
                            <video controls>
                                <source src="<?php echo $url; ?>" type="video/mp4">
                                Seu navegador não suporta o elemento de vídeo.
                            </video>
                        <?php endif; ?>
                        <br>
                        <a href="admin2.php?delete=<?php echo $row['id']; ?>" class="button button-danger" onclick="return confirm('Tem certeza que deseja remover este vídeo?')">Remover Vídeo</a>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p>Nenhum vídeo cadastrado.</p>
        <?php endif; ?>
    </div>

    <?php
    $conn->close();
    ?>
</body>
</html>
