<!-- Listar Vídeos -->
<div class="form-container">
    <h2>Vídeos Cadastrados</h2>
    <?php
    $sql = "SELECT * FROM videos";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<div class='video-grid'>";
        while ($row = $result->fetch_assoc()) {
            echo "<div class='video-item'>";
            echo "<h2>" . htmlspecialchars($row['title']) . "</h2>";
            echo "<p>Descrição: " . htmlspecialchars($row['description']) . "</p>";
            echo "<p>Categoria: " . htmlspecialchars($row['category']) . "</p>";

            // Verificar se o URL é do YouTube
            $url = htmlspecialchars($row['file_path']);
            if (strpos($url, 'youtube.com') !== false || strpos($url, 'youtu.be') !== false) {
                // Extrair o ID do vídeo do YouTube
                preg_match('/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:v\/|embed\/|watch\?v=)|youtu\.be\/)([^\s"&?\/]{11})/', $url, $matches);
                $video_id = $matches[1] ?? null;

                if ($video_id) {
                    echo "<iframe width='560' height='315' src='https://www.youtube.com/embed/" . $video_id . "' frameborder='0' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>";
                } else {
                    echo "<p>URL do vídeo inválida.</p>";
                }
            } else {
                echo "<p>URL não é um link do YouTube.</p>";
            }
            
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "<p>Nenhum vídeo cadastrado.</p>";
    }
    ?>
</div>
