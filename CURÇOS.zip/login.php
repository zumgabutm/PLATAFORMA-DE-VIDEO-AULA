<?php
session_start();
include('conexao.php');

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    // Verifica se o usuário existe
    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // Verifica se a senha está correta
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            header('Location: home.php');
            exit(); // Assegura que o script seja interrompido após o redirecionamento
        } else {
            $error = "Senha incorreta.";
        }
    } else {
        $error = "Usuário não encontrado.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>
    <div class="login-container">
        <div class="login-form">
            <div class="login-logo">
                <img src="https://rszum.shop/imdb/uploads/baner.png" alt="Logo"> <!-- Substitua pelo caminho da sua logomarca -->
            </div>
            <form method="post" action="login.php">
                <h1>TESTE</h1>
                <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
                <label for="username">LOGIN</label>
                <input type="text" id="username" name="username" required>
                <label for="password">Senha:</label>
                <input type="password" id="password" name="password" required>
                <button type="submit">Entrar</button>
            </form>
        </div>
    </div>
</body>
</html>
