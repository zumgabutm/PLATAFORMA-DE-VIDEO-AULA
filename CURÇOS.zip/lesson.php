<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

include('conexao.php');
$lesson_id = $_GET['lesson_id'];
$sql = "SELECT * FROM lessons WHERE id='$lesson_id'";
$lesson = $conn->query($sql)->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Aula</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1><?= $lesson['title'] ?></h1>
    <video id="lessonVideo" src="<?= $lesson['video_url'] ?>" controls></video>
    <script src="script.js"></script>
</body>
</html>
