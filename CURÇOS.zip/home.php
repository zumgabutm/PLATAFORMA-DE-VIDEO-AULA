<?php
session_start();
include('conexao.php');

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Verificar se o usuário deseja sair
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}

// Definir categorias manualmente
$categories = [
    'ANDROID',
    'WIFI',
    'PEN_TEST',
    'INFORMATICA',
    'MODIFICACOES',
    'METODOS'
];

// Filtrar vídeos por categoria se a categoria for definida
$category_filter = '';
if (isset($_GET['category']) && in_array($_GET['category'], $categories)) {
    $category_filter = $_GET['category'];
    $stmt = $conn->prepare("SELECT * FROM videos WHERE category = ? ORDER BY id ASC");
    $stmt->bind_param("s", $category_filter);
    $stmt->execute();
    $videos_result = $stmt->get_result();
} else {
    $stmt = $conn->prepare("SELECT * FROM videos ORDER BY id ASC");
    $stmt->execute();
    $videos_result = $stmt->get_result();
}

// Obter vídeos da categoria selecionada
$videos = [];
while ($row = $videos_result->fetch_assoc()) {
    $videos[] = $row;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Vídeos por Categoria</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        /* CSS Geral */
body {
    font-family: Arial, sans-serif;
    background: linear-gradient(to right, rgba(0, 198, 255, 0.05), rgba(0, 114, 255, 0.05)), url('https://rszum.shop/imdb/uploads/unnamed.jpg') no-repeat center center fixed; /* Gradiente de fundo com imagem */
    background-size: cover;
    color: #fff;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background: rgba(0, 0, 0, 0.8); /* Fundo escuro e semi-transparente */
    border-radius: 10px;
    position: relative;
}

.logout-button {
    background-color: #dc3545;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    position: absolute;
    top: 20px;
    right: 20px;
    transition: background-color 0.3s;
}

.logout-button:hover {
    background-color: #c82333;
}

.category-menu {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    margin-bottom: 20px;
}

.category-item {
    margin: 10px;
}

.category-item a {
    text-decoration: none;
    color: #007bff;
    font-size: 18px;
    padding: 10px 20px;
    border-radius: 5px;
    background-color: #fff;
    border: 1px solid #007bff;
    transition: background-color 0.3s, color 0.3s;
}

.category-item a:hover {
    background-color: #007bff;
    color: #fff;
}

.category-title {
    font-size: 22px;
    font-weight: bold;
    margin-bottom: 10px;
}

.back-button {
    display: inline-block;
    margin-bottom: 20px;
    padding: 10px 20px;
    background-color: #007bff;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.back-button:hover {
    background-color: #0056b3;
}

.video-grid {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}

.video-item {
    width: 100%;
    max-width: 560px;
    margin: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    padding: 10px;
    border-radius: 5px;
    background: #fff;
}

.video-item h2 {
    font-size: 18px;
    margin: 0;
}

.video-item p {
    font-size: 14px;
    color: #555;
}

.video-item video, .video-item iframe {
    width: 100%;
    border-radius: 5px;
}

@media (min-width: 768px) {
    .video-item {
        width: 45%;
    }
}

@media (min-width: 992px) {
    .video-item {
        width: 30%;
    }
}

    </style>
</head>
<body>
    <div class="container">
        <!-- Botão Sair -->
        <a href="?logout" class="logout-button">Sair</a>

        <h1 class="text-center">Bem-vindo ao Portal de Vídeos</h1>

        <!-- Página Inicial -->
        <div id="home-page">
            <h2 class="text-center">Selecione uma Categoria para Começar</h2>
            <div class="category-menu">
                <?php foreach ($categories as $category): ?>
                    <div class="category-item">
                        <a href="home.php?category=<?php echo urlencode($category); ?>">
                            <?php echo htmlspecialchars($category); ?>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Vídeos -->
        <div id="videos-page" style="<?php echo $category_filter ? 'display: block;' : 'display: none;'; ?>">
            <a href="home.php" class="back-button">Voltar ao Início</a>
            <h2 class="category-title"><?php echo htmlspecialchars($category_filter); ?></h2>
            <div class="video-grid">
                <?php if (!empty($videos)): ?>
                    <?php foreach ($videos as $video): ?>
                        <div class="video-item">
                            <h2><?php echo htmlspecialchars($video['title']); ?></h2>
                            <p><?php echo htmlspecialchars($video['description']); ?></p>
                            <?php
                            $url = htmlspecialchars($video['file_path']);
                            if (strpos($url, 'youtube.com') !== false || strpos($url, 'youtu.be') !== false):
                                // Extrair o ID do vídeo do YouTube
                                preg_match('/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:v\/|embed\/|watch\?v=)|youtu\.be\/)([^\s"&?\/]{11})/', $url, $matches);
                                $video_id = $matches[1] ?? null;

                                if ($video_id):
                            ?>
                                <iframe src="https://www.youtube.com/embed/<?php echo $video_id; ?>" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            <?php else: ?>
                                <p>URL do vídeo inválida.</p>
                            <?php endif; ?>
                            <?php elseif (filter_var($url, FILTER_VALIDATE_URL)): ?>
                                <!-- Vídeo a partir de um link -->
                                <video controls>
                                    <source src="<?php echo $url; ?>" type="video/mp4">
                                    Seu navegador não suporta o elemento de vídeo.
                                </video>
                            <?php else: ?>
                                <!-- Vídeo carregado por upload -->
                                <video controls>
                                    <source src="<?php echo $url; ?>" type="video/mp4">
                                    Seu navegador não suporta o elemento de vídeo.
                                </video>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>Nenhum vídeo encontrado nesta categoria.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            const homePage = $('#home-page');
            const videosPage = $('#videos-page');
            const categoryFilter = '<?php echo $category_filter; ?>';

            if (categoryFilter) {
                homePage.hide();
                videosPage.show();
            } else {
                homePage.show();
                videosPage.hide();
            }
        });
    </script>
</body>
</html>
