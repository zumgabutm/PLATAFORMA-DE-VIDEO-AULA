<?php
session_start();
include('conexao.php');

if (!isset($_SESSION['user_id'])) {
    die('Você precisa estar logado para registrar o progresso.');
}

$user_id = $_SESSION['user_id'];
$video_id = intval($_POST['video_id']);

if ($video_id > 0) {
    $stmt = $conn->prepare("INSERT INTO user_progress (user_id, video_id) VALUES (?, ?) ON DUPLICATE KEY UPDATE unlocked_at = NOW()");
    $stmt->bind_param('ii', $user_id, $video_id);
    $stmt->execute();
    $stmt->close();
}

$conn->close();
?>
