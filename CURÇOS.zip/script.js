document.getElementById('lessonVideo').addEventListener('ended', function() {
    fetch('complete_lesson.php?lesson_id=' + <?= $_GET['lesson_id'] ?>);
});
